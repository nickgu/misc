/***************************************************************************
 * 
 * Copyright (c) 2013 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/



/**
 * @file test.cpp
 * @author gusimiu(com@baidu.com)
 * @date 2013/06/26 14:15:34
 * @brief 
 *  
 **/
#include <python2.7/Python.h> //����python��ͷ�ļ�

#include <cstdio>
#include <string>
using namespace std;

#include <ul_dictmatch.h>

// ����������ʵ��һ��ȫ�ִʵ䡣��
static dm_dict_t* g_dmdict = NULL;
static dm_pack_t* g_dmpack = NULL;

// 2 python ��װ
static PyObject * wrapper_create(PyObject *self, PyObject *args) 
{
    int ret = 0;
    g_dmdict = dm_dict_create(10000000);
    g_dmpack = dm_pack_create(100000);
    return Py_BuildValue("i", ret);//��c�ķ���ֵnת����python�Ķ���
}

static PyObject * wrapper_add(PyObject *self, PyObject *args) 
{
    char* text;
    int prop = 0;
    int sz = PyTuple_Size(args);
    if (sz == 1) {
        if (!PyArg_ParseTuple(args, "s", &text)) {
            fprintf(stderr, "Parse tuple (text) error!\n"); 
            return NULL;
        }
    } else {
        if (!PyArg_ParseTuple(args, "si", &text, &prop)) {
            fprintf(stderr, "Parse tuple (text, prop) error!\n"); 
            return NULL;
        }
    }
    if (g_dmdict==NULL || g_dmpack==NULL) {
        fprintf(stderr, "You need to init dmdict before use.\n");
        return NULL;
    }
    dm_lemma_t lemma;
    lemma.pstr = text;
    lemma.prop = prop;
    lemma.len = strlen(text);
    if (lemma.len<=0) {
        return Py_BuildValue("i", -1);   
    }
    //fprintf(stderr, "ADD: [%s]\n", text);
    dm_add_lemma(g_dmdict, &lemma);
    return Py_BuildValue("i", 0);
}

static PyObject* wrapper_find(PyObject *self, PyObject *args) {
    const char* text;
    if (!PyArg_ParseTuple(args, "s", &text)) {
        fprintf(stderr, "Parse tuple (text) error!\n"); 
        return NULL;
    }
    if (g_dmdict==NULL || g_dmpack==NULL) {
        fprintf(stderr, "You need to init dmdict before use.\n");
        return NULL;
    }
    
    //printf("TEXT[%d]: %s\n", (int)strlen(text), text);
    dm_search(g_dmdict, g_dmpack, text, strlen(text), DM_OUT_ALL);
    PyObject* pList = PyList_New(g_dmpack->ppseg_cnt);
    for (u_int i=0; i<g_dmpack->ppseg_cnt; ++i) {
        PyObject* pTuple = PyTuple_New(4);
        dm_lemma_t *lm = g_dmpack->ppseg[i];

        //printf("{%s} [%d,%d]\n", lm->pstr, g_dmpack->poff[i], g_dmpack->poff[i] + lm->len);
        PyTuple_SetItem(pTuple, 0, PyString_FromString(lm->pstr));
        PyTuple_SetItem(pTuple, 1, PyInt_FromLong(g_dmpack->poff[i]));
        PyTuple_SetItem(pTuple, 2, PyInt_FromLong(lm->len));
        PyTuple_SetItem(pTuple, 3, PyInt_FromLong(lm->prop));
        PyList_SetItem(pList, i, pTuple);   
    }
    return pList;
}

// load.
static PyObject* wrapper_load(PyObject *self, PyObject *args) 
{
    const char* path;
    if (!PyArg_ParseTuple(args, "s", &path)) {
        fprintf(stderr, "Parse tuple error!\n"); 
        return NULL;
    }
    g_dmdict = dm_binarydict_load(path);
    g_dmpack = dm_pack_create(100000);
    //printf("%p:%p", g_dmdict, g_dmpack);
    return Py_BuildValue("i", 0);
}
// save.
static PyObject* wrapper_save(PyObject *self, PyObject *args) 
{
    const char* path;
    if (!PyArg_ParseTuple(args, "s", &path)) {
        fprintf(stderr, "Parse tuple error!\n"); 
        return NULL;
    }
    if (g_dmdict==NULL || g_dmpack==NULL) {
        fprintf(stderr, "You need to init dmdict before use.\n");
        return NULL;
    }
    int ret = dm_binarydict_save(g_dmdict, path);
    return Py_BuildValue("i", ret);
}

// 3 �����б�
static PyMethodDef MyCppMethods[] = {
    //MyCppFun1��python��ע��ĺ�������wrap_my_c_fun�Ǻ���ָ��
    { "create", wrapper_create, METH_VARARGS, "create a dm search dict."},
    { "load", wrapper_load, METH_VARARGS, "load a dm dict."},
    { "save", wrapper_save, METH_VARARGS, "save a dm dict."},
    { "add", wrapper_add, METH_VARARGS, "add a lemma."},
    { "find", wrapper_find, METH_VARARGS, "do match."},
    { NULL, NULL, 0, NULL }
};
// 4 ģ���ʼ������
PyMODINIT_FUNC initc_dmsearch(void) {
    //��ʼģ�飬��MyCppMethods��ʼ��MyCppModule��
    PyObject *m = Py_InitModule("c_dmsearch", MyCppMethods);
    if (m == NULL)
        return;
}

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
