/***************************************************************************
 * 
 * Copyright (c) 2007 Baidu.com, Inc. All Rights Reserved
 * $Id: ul_exlink.h,v 1.2 2008/08/13 02:28:55 baonh Exp $ 
 * 
 **************************************************************************/



/**
 * @file ul_exlink.h
 * @author com-dev (com-dev@baidu.com)
 * @date 2007/12/14 11:07:50
 * @version $Revision: 1.2 $ 
 * @brief url��ȡ 
 */



#ifndef __UL_EXLINK_H__
#define __UL_EXLINK_H__


#include "dep/dep_exlink.h"


#endif
/* vim: set ts=4 sw=4 sts=4 tw=100 noet: */
