/**************************************************************************
		Header of all utilities 
**************************************************************************/

#ifndef __UTIL_H__
#define __UTIL_H__

#include "ul_def.h"
//	#include "l_log.h"
//	#include "l_call.h"
//	#include "l_conf.h"
//	#include "l_other.h"
//	#include "l_file.h"
//	#include "iconf.h"

#endif
