#ifndef __CHARSET_H__
#define __CHARSET_H__

extern char legal_char_set[256];
extern char url_eng_set[256];
extern char legal_word_set[256];

#endif
