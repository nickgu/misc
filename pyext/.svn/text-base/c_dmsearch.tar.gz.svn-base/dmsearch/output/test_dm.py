#! /bin/env python
# encoding=utf-8
# gusimiu@baidu.com
# 

import sys
import c_dmsearch

if __name__=='__main__':
    c_dmsearch.create()
    if len(sys.argv)>=2 and sys.argv[1] == '-l':
        sys.stderr.write('Run in load mode:\n')
        c_dmsearch.load('./test.dm')

    else:
        sys.stderr.write('Run in save mode:\n')
        c_dmsearch.add('abcdef', 1)
        c_dmsearch.add('ab', 3)
        c_dmsearch.add('cde')

        c_dmsearch.save('./test.dm')

    for ans in c_dmsearch.find('this is a abcdef and abc and abcde text'):
        print ans
