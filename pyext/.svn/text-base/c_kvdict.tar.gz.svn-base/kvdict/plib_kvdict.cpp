/***************************************************************************
 * 
 * Copyright (c) 2013 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/



/**
 * @file test.cpp
 * @author gusimiu(com@baidu.com)
 * @date 2013/06/26 14:15:34
 * @brief 
 *  
 **/
#include <python2.7/Python.h> //����python��ͷ�ļ�

#include <map>
#include <string>
#include <vector>
#include "ul_sign.h"
#include <ext/hash_map>

using namespace __gnu_cxx;
using namespace std;

struct DiskData_t {
    size_t fid:4;
    size_t bpos:40;
    size_t size:20;
};

typedef hash_map<size_t, const char*> Dict_t;
typedef hash_map<size_t, DiskData_t> DiskDict_t;
typedef Dict_t::iterator DictIterator_t;

struct KVDict_t {
    bool memory_mode;
    char buffer[1024*128];
    DiskDict_t disk_dict;
    Dict_t dict;
    vector<FILE*> fps;
};

vector<KVDict_t*> g_dict_pool;

static size_t calc_sign(const char* s) {
    unsigned slen = strlen(s);
    unsigned low;
    unsigned high;
    creat_sign_f64((char*)s, slen, &low, &high);
    size_t ret = high;
    ret = (ret << 32LL) | low;
    return ret;
}

/*
 * ��������ļ���ȡһ������
 */
int fgets_random(char* buffer,size_t buffer_size, const vector<FILE*> fps, const DiskData_t& d)
{
    if (d.fid<(size_t)0 || d.fid>=(size_t)fps.size()) {
        return -1;
    }
    FILE* fp = fps[d.fid];
    int ret = fseek(fp, d.bpos, SEEK_SET); 
    if (ret<0) {
        return ret;
    }
    buffer[d.size] = 0;
    return fread(buffer, d.size, 1, fp);
}

int load(int dict_id, 
        int fcnt, 
        vector<char*> fn_list, 
        int key_column, 
        bool load_in_memory) 
{
    KVDict_t* pdict = g_dict_pool[dict_id];
    pdict->memory_mode = load_in_memory;
    //fprintf(stderr, "FCNT=%d KEY_COLUMN=%d LOADMEMORY=%d\n", fcnt, key_column, load_in_memory);
    char* line = pdict->buffer;
    size_t MAX_LINE_LENGTH = sizeof(pdict->buffer);
    int fid = 0;
    for (int id=0; id<fcnt; ++id) {
        FILE* fp = fopen(fn_list[id], "r");
        if (fp==NULL) {
            fprintf(stderr, "Cannot open file : %s\n", fn_list[id]);
            continue;
        }
        size_t fpos_b = ftell(fp);
        unsigned counter = 0;
        while (fgets(line, MAX_LINE_LENGTH, fp)) {
            unsigned line_len = strlen(line);
            // strip.
            line[line_len-1] = 0;
            size_t fpos_e = ftell(fp);

            size_t sign;
            const char* value_pos = NULL;
            unsigned value_length = 0;
            unsigned value_offset = 0;
            for (int i=0; line[i]; ++i) {
                if (line[i]=='\t') {
                    line[i] = 0;
                    sign = calc_sign(line);
                    value_pos = line+i+1;
                    value_offset = i+1;
                    value_length = line_len - i - 1;
                    break;
                }
            }

            if (value_pos!=NULL) {
                if (pdict->memory_mode) {
                    char *content = new char[value_length + 1];
                    strncpy(content, value_pos, value_length);
                    content[value_length] = 0;
                    pdict->dict[sign] = content;
                } else {
                    DiskData_t d;
                    d.fid = fid;
                    d.bpos = fpos_b + value_offset;
                    d.size = fpos_e - 1 - fpos_b - value_offset;
                    pdict->disk_dict[sign] = d;
                }
            }
            fpos_b = fpos_e;

            counter ++;
            if (counter % 1000000==0) {
                fprintf(stderr, "Load %d records over.\n", counter);
            }
        }
        if (pdict->memory_mode) {
            fclose(fp);
        } else {
            pdict->fps.push_back(fp);
            fid ++;
        }
    }
    fprintf(stderr, "LoadDictOver! Dsize=%u DiskIndexSize=%u\n", 
            pdict->dict.size(), 
            pdict->disk_dict.size());
    return 0;
}

int seek(int dict_id, 
        const char* k, 
        string& out) 
{
    KVDict_t* pdict = g_dict_pool[dict_id];
    string key = k;
    size_t sign = calc_sign(key.c_str());
    if (pdict->memory_mode) {
        if (pdict->dict.find(sign)==pdict->dict.end()) {
            return 0;
        }
        out = pdict->dict[sign];
    } else {
        if (pdict->disk_dict.find(sign)==pdict->disk_dict.end()) {
            return 0;
        }
        DiskData_t d = pdict->disk_dict[sign];
        fgets_random(pdict->buffer, sizeof(pdict->buffer), pdict->fps, d);
        out = string(pdict->buffer);
    }
    return 1;
}

static PyObject * wrapper_create(PyObject *self, PyObject *args)  {
    int did = g_dict_pool.size();
    // create new.
    g_dict_pool.push_back(new KVDict_t());
    return Py_BuildValue("i", did);
}

// 2 python ��װ
static PyObject * wrapper_load(PyObject *self, PyObject *args) 
{
    int did = PyInt_AsLong(PyTuple_GetItem(args, 0));
    int fcnt = PyInt_AsLong(PyTuple_GetItem(args, 1));
    vector<char*> fn_list; 
    PyObject *flist = PyTuple_GetItem(args, 2);
    for (int i=0; i<fcnt; ++i) {
        PyObject* o = PyList_GetItem(flist, i);
        char* fn = PyString_AsString(o);
        fn_list.push_back(fn);
    }
    int key_column = PyInt_AsLong(PyTuple_GetItem(args, 3));
    bool load_in_memory = (bool)PyInt_AsLong(PyTuple_GetItem(args, 4));

    int ret = load(did, fcnt, fn_list, key_column, load_in_memory);
    return Py_BuildValue("i", ret);//��c�ķ���ֵnת����python�Ķ���
}

static PyObject * wrapper_seek(PyObject *self, PyObject *args) {
    int did = PyInt_AsLong(PyTuple_GetItem(args, 0));
    const char* key = PyString_AsString(PyTuple_GetItem(args, 1));
    string out;
    int found = seek(did, key, out);
    if (found) {
        return Py_BuildValue("s", out.c_str());
    } else {
        Py_INCREF(Py_None);
        return Py_None;
    }
}

// 3 �����б�
static PyMethodDef MyCppMethods[] = {
    //MyCppFun1��python��ע��ĺ�������wrap_my_c_fun�Ǻ���ָ��
    { "create", wrapper_create, METH_VARARGS, "create a dict."},
    { "load", wrapper_load, METH_VARARGS, "load files into dict."},
    { "seek", wrapper_seek, METH_VARARGS, "search dict."},
    { NULL, NULL, 0, NULL }
};
// 4 ģ���ʼ������
PyMODINIT_FUNC initc_kvdict(void) {
    //��ʼģ�飬��MyCppMethods��ʼ��MyCppModule��
    PyObject *m = Py_InitModule("c_kvdict", MyCppMethods);
    if (m == NULL)
        return;
}

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
